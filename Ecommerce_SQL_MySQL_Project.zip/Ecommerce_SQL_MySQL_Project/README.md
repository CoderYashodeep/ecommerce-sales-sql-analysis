# E-Commerce Sales Analysis – MySQL

## Objective
Analyze an e-commerce database using SQL. This project demonstrates data retrieval, filtering, sorting, aggregation, joins, subqueries, views, indexes, and NULL handling.

## Tools
- MySQL 8.0+
- MySQL Workbench (recommended free GUI)
- GitHub

## Database
Database name: `ecommerce_sales`

Tables:
1. `customers` – customer information
2. `products` – product details and prices
3. `orders` – order information
4. `order_items` – products and quantities in each order

## Run the project
1. Install MySQL Community Server and MySQL Workbench.
2. Open MySQL Workbench and connect to your local MySQL server.
3. Open `queries/ecommerce_analysis_mysql.sql`.
4. Execute the script. It creates the database, tables, sample data, views, indexes and analysis queries.
5. Review the result grids and save screenshots in `screenshots/`.

## Concepts covered
- SELECT, WHERE, ORDER BY
- GROUP BY, HAVING
- COUNT, SUM, AVG, MIN, MAX
- INNER JOIN, LEFT JOIN, RIGHT JOIN
- Subqueries
- Average revenue per purchasing customer (ARPU)
- Views
- Indexes and EXPLAIN
- NULL handling with IS NULL and COALESCE

## Notes
- This project uses MySQL syntax, not SQLite syntax.
- `email` uses `VARCHAR(255) UNIQUE`, avoiding MySQL Error 1170.
- Monetary values use DECIMAL rather than floating-point types.
- Sample data is fictional.
- Revenue is calculated as quantity multiplied by unit_price.
- ARPU is total recorded order-item revenue divided by distinct customers who have orders.
- The script drops and recreates its project tables and views each time it is run. Do not run it against a database containing data you need to keep.

## Repository layout
```text
Ecommerce_SQL_MySQL_Project/
├── queries/
│   └── ecommerce_analysis_mysql.sql
├── database/
├── screenshots/
└── README.md
```
