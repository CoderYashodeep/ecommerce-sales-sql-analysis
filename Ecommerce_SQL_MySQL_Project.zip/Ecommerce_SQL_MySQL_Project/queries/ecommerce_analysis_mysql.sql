-- ============================================================
-- TASK 3: SQL FOR DATA ANALYSIS
-- Project: E-Commerce Sales Analysis
-- Database: MySQL 8.0+
-- Run this complete script in MySQL Workbench.
-- ============================================================

CREATE DATABASE IF NOT EXISTS ecommerce_sales;
USE ecommerce_sales;

-- Enable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

DROP VIEW IF EXISTS customer_revenue;
DROP VIEW IF EXISTS product_sales_summary;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- 1. CREATE TABLES
-- ============================================================

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    email VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    CONSTRAINT chk_product_price CHECK (price >= 0),
    CONSTRAINT chk_stock_quantity CHECK (stock_quantity >= 0)
) ENGINE=InnoDB;

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    status VARCHAR(30) NOT NULL,
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
) ENGINE=InnoDB;

CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(12,2) NOT NULL,
    CONSTRAINT chk_order_quantity CHECK (quantity > 0),
    CONSTRAINT chk_unit_price CHECK (unit_price >= 0),
    CONSTRAINT fk_items_order
        FOREIGN KEY (order_id)
        REFERENCES orders(order_id),
    CONSTRAINT fk_items_product
        FOREIGN KEY (product_id)
        REFERENCES products(product_id)
) ENGINE=InnoDB;

-- ============================================================
-- 2. INSERT SAMPLE DATA
-- ============================================================

INSERT INTO customers (customer_id, customer_name, city, email) VALUES
(1, 'Aarav Sharma', 'Pune', 'aarav@example.com'),
(2, 'Priya Patel', 'Mumbai', 'priya@example.com'),
(3, 'Rohan Mehta', 'Delhi', 'rohan@example.com'),
(4, 'Sneha Iyer', 'Bengaluru', 'sneha@example.com'),
(5, 'Kabir Singh', 'Pune', 'kabir@example.com'),
(6, 'Ananya Rao', 'Hyderabad', 'ananya@example.com'),
(7, 'Ishaan Gupta', 'Chennai', 'ishaan@example.com');

INSERT INTO products (product_id, product_name, category, price, stock_quantity) VALUES
(101, 'Laptop', 'Electronics', 55000.00, 12),
(102, 'Wireless Mouse', 'Accessories', 800.00, 50),
(103, 'Keyboard', 'Accessories', 1500.00, 35),
(104, 'Smartphone', 'Electronics', 30000.00, 18),
(105, 'Headphones', 'Accessories', 2500.00, 25),
(106, 'Office Chair', 'Furniture', 7000.00, 10),
(107, 'Desk Lamp', 'Furniture', 1200.00, 20),
(108, 'Monitor', 'Electronics', 12000.00, 8);

INSERT INTO orders (order_id, customer_id, order_date, status) VALUES
(1001, 1, '2026-10-01', 'Delivered'),
(1002, 2, '2026-10-02', 'Delivered'),
(1003, 1, '2026-10-05', 'Shipped'),
(1004, 3, '2026-10-08', 'Delivered'),
(1005, 4, '2026-10-10', 'Pending'),
(1006, 5, '2026-10-12', 'Delivered'),
(1007, 2, '2026-10-15', 'Shipped'),
(1008, 6, '2026-10-18', 'Delivered');

INSERT INTO order_items
(order_item_id, order_id, product_id, quantity, unit_price) VALUES
(1, 1001, 101, 1, 55000.00),
(2, 1001, 102, 2, 800.00),
(3, 1002, 104, 1, 30000.00),
(4, 1002, 105, 1, 2500.00),
(5, 1003, 103, 2, 1500.00),
(6, 1003, 105, 1, 2500.00),
(7, 1004, 106, 1, 7000.00),
(8, 1004, 107, 2, 1200.00),
(9, 1005, 108, 1, 12000.00),
(10, 1006, 102, 3, 800.00),
(11, 1006, 103, 1, 1500.00),
(12, 1007, 101, 1, 55000.00),
(13, 1008, 104, 1, 30000.00),
(14, 1008, 105, 2, 2500.00);

-- ============================================================
-- 3. VERIFY TABLES AND DATA
-- ============================================================

SHOW TABLES;
SELECT * FROM customers;
SELECT * FROM products;
SELECT * FROM orders;
SELECT * FROM order_items;

-- ============================================================
-- 4. SELECT, WHERE, ORDER BY
-- ============================================================

-- Q1: Display all customers
SELECT * FROM customers;

-- Q2: Customers from Pune
SELECT *
FROM customers
WHERE city = 'Pune';

-- Q3: Products sorted by highest price
SELECT product_name, category, price
FROM products
ORDER BY price DESC;

-- Q4: Products costing more than 5000
SELECT product_name, price
FROM products
WHERE price > 5000
ORDER BY price DESC;

-- ============================================================
-- 5. AGGREGATE FUNCTIONS AND GROUP BY
-- ============================================================

-- Q5: Count customers and products
SELECT
    (SELECT COUNT(*) FROM customers) AS total_customers,
    (SELECT COUNT(*) FROM products) AS total_products;

-- Q6: Total revenue
SELECT
    ROUND(SUM(quantity * unit_price), 2) AS total_revenue
FROM order_items;

-- Q7: Average product price
SELECT
    ROUND(AVG(price), 2) AS average_product_price
FROM products;

-- Q8: Revenue by product category
SELECT
    p.category,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS category_revenue
FROM products p
INNER JOIN order_items oi
    ON p.product_id = oi.product_id
GROUP BY p.category
ORDER BY category_revenue DESC;

-- Q9: Categories with revenue greater than 10000
SELECT
    p.category,
    SUM(oi.quantity * oi.unit_price) AS category_revenue
FROM products p
INNER JOIN order_items oi
    ON p.product_id = oi.product_id
GROUP BY p.category
HAVING SUM(oi.quantity * oi.unit_price) > 10000;

-- Q10: Minimum and maximum product prices
SELECT
    MIN(price) AS minimum_price,
    MAX(price) AS maximum_price
FROM products;

-- ============================================================
-- 6. JOINS
-- ============================================================

-- Q11: INNER JOIN - matching customer orders
SELECT
    o.order_id,
    c.customer_name,
    o.order_date,
    o.status
FROM orders o
INNER JOIN customers c
    ON o.customer_id = c.customer_id
ORDER BY o.order_id;

-- Q12: LEFT JOIN - all customers, including those without orders
SELECT
    c.customer_id,
    c.customer_name,
    o.order_id,
    o.status
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id
ORDER BY c.customer_id;

-- Q13: RIGHT JOIN - all customers, including those without orders
SELECT
    c.customer_id,
    c.customer_name,
    o.order_id,
    o.status
FROM orders o
RIGHT JOIN customers c
    ON o.customer_id = c.customer_id
ORDER BY c.customer_id;

-- Q14: Join customers, orders and order items to calculate order totals
SELECT
    c.customer_name,
    o.order_id,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS order_total
FROM customers c
INNER JOIN orders o
    ON c.customer_id = o.customer_id
INNER JOIN order_items oi
    ON o.order_id = oi.order_id
GROUP BY c.customer_name, o.order_id
ORDER BY order_total DESC;

-- Q15: Join products and order items
SELECT
    p.product_name,
    oi.quantity,
    oi.unit_price,
    (oi.quantity * oi.unit_price) AS line_total
FROM products p
INNER JOIN order_items oi
    ON p.product_id = oi.product_id
ORDER BY line_total DESC;

-- ============================================================
-- 7. SUBQUERIES
-- ============================================================

-- Q16: Products priced above average product price
SELECT product_name, price
FROM products
WHERE price > (
    SELECT AVG(price)
    FROM products
)
ORDER BY price DESC;

-- Q17: Customers who have placed at least one order
SELECT customer_name
FROM customers
WHERE customer_id IN (
    SELECT DISTINCT customer_id
    FROM orders
);

-- Q18: Product(s) with the highest price
SELECT product_name, price
FROM products
WHERE price = (
    SELECT MAX(price)
    FROM products
);

-- ============================================================
-- 8. AVERAGE REVENUE PER USER (ARPU)
-- ============================================================

-- Q19: Revenue per purchasing customer
SELECT
    ROUND(
        SUM(oi.quantity * oi.unit_price)
        / NULLIF(COUNT(DISTINCT o.customer_id), 0),
        2
    ) AS average_revenue_per_purchasing_customer
FROM orders o
INNER JOIN order_items oi
    ON o.order_id = oi.order_id;

-- ============================================================
-- 9. VIEWS FOR ANALYSIS
-- ============================================================

-- Q20: Customer revenue view
CREATE VIEW customer_revenue AS
SELECT
    c.customer_id,
    c.customer_name,
    COUNT(DISTINCT o.order_id) AS total_orders,
    COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_revenue
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id
LEFT JOIN order_items oi
    ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_name;

-- Q21: Product sales summary view
CREATE VIEW product_sales_summary AS
SELECT
    p.product_id,
    p.product_name,
    p.category,
    COALESCE(SUM(oi.quantity), 0) AS units_sold,
    COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_revenue
FROM products p
LEFT JOIN order_items oi
    ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name, p.category;

-- Run views
SELECT * FROM customer_revenue
ORDER BY total_revenue DESC;

SELECT * FROM product_sales_summary
ORDER BY total_revenue DESC;

-- ============================================================
-- 10. INDEXES AND QUERY OPTIMIZATION
-- ============================================================

CREATE INDEX idx_orders_customer_id
ON orders(customer_id);

CREATE INDEX idx_orders_order_date
ON orders(order_date);

CREATE INDEX idx_order_items_order_id
ON order_items(order_id);

CREATE INDEX idx_order_items_product_id
ON order_items(product_id);

-- Inspect execution plan
EXPLAIN
SELECT
    o.order_id,
    c.customer_name
FROM orders o
INNER JOIN customers c
    ON o.customer_id = c.customer_id
WHERE o.customer_id = 1;

-- ============================================================
-- 11. NULL HANDLING
-- ============================================================

-- Q22: Replace NULL city with Unknown in query output
SELECT
    customer_name,
    COALESCE(city, 'Unknown') AS city
FROM customers;

-- Q23: Find customers with missing city
SELECT *
FROM customers
WHERE city IS NULL;

-- Q24: Find orders with missing customer ID
SELECT *
FROM orders
WHERE customer_id IS NULL;

-- ============================================================
-- 12. ADD A NULL EXAMPLE FOR DEMONSTRATION
-- ============================================================

-- This demonstrates NULL handling without changing the original
-- sample customer records.
INSERT INTO customers (customer_id, customer_name, city, email)
VALUES (8, 'Test Customer', NULL, 'testcustomer@example.com');

SELECT
    customer_name,
    COALESCE(city, 'Unknown') AS city
FROM customers
WHERE customer_id = 8;

-- Remove demonstration row after the NULL example
DELETE FROM customers
WHERE customer_id = 8;

-- ============================================================
-- END OF MYSQL PROJECT
-- ============================================================
